/* 
 * steg-encode.c
 * 
 * Řešení IJC-DU1, příklad b)
 * Datum vytvoření: 3.3.2020
 * Autor: Tomáš Milostný, xmilos02, FIT VUT
 * Překladač: gcc 7.4
 * Popis: Steganografický enkodér - Program zašifruje tajnou zprávu do souboru.
 *        Znaky zprávy jsou uložney na nejnižších významový bytech RBG bytů PPM obrázku.
 *        Vybrané byty jsou prvočíla počínaje 23.
 */
		  

int main(int argc, char **argv)
{



	return 0;
}